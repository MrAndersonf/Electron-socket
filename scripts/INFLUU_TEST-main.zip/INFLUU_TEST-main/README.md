# INFLUU_TEST
Test for INFLUU using Puppeteer
* how to start this project
* npm install
* node index.js
